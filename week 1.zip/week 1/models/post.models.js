let posts = require(filename);



const getposts= ()=> {

    return new Promise((resolve, reject)=>{
        if (posts.length === 0){
            reject({
                message: "Sorry, no posts availaible to display!!",
                status: 202
            })
        }
    })
}

const getpost = ()=> {

}

const insertpost = ()=> {

}

const updatepost = ()=> {

}

const elementpost = () => {

}